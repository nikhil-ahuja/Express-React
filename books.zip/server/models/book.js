var Sequelize = require('sequelize');
var Promise = require('bluebird');


module.exports = function (sequelize, DataTypes) {
    var Book = sequelize.define('Book', {
        title: {
            type: Sequelize.STRING,
            allowNull: false,
            field: 'title'
        },
        createdAt: {
            type: Sequelize.DATE,
            field: 'created_at'
        },
        updatedAt: {
            type: Sequelize.DATE,
            field: 'updated_at'
        },
        isbn:{
            type: Sequelize.STRING,
            allowNull: false,
            field: 'isbn'
        },
        publicationDate:{
            type: Sequelize.DATE,
            field: 'publication_date'
        },
        author:{
            type: Sequelize.STRING,
            field: 'author'
        }
    }, {
        hooks: {

        },
        underscored: true,
        tableName: 'books'
    });
    return Book;
};

