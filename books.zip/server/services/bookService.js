var errors = require('restify-errors');
var logger = require('../config/logger');
var successHandler = require('../responseHandlers/successHandler');
var models = require('../models');
var Promise = require("bluebird");
const FILE_NAME = 'bookService';


exports.saveBookDetails = function (req, res, next) {
    var FUNCTION_NAME = 'saveBookDetails';

    logger.debug('Inside File: '+FILE_NAME+' Function: '+FUNCTION_NAME);


    var title = req.body.title;
    var isbn = req.body.isbn;
    var author = req.body.author;


    if(!title){
        return next(new errors.BadRequestError('Title cannot be empty'));
    }
    if(!isbn){
        return next(new errors.BadRequestError('ISBN cannot be empty'));
    }
    if(!author){
        return next(new errors.BadRequestError('Author cannot be empty'));
    }


    var data = {
        title: title,
        isbn: isbn,
        author: author
    };

    logger.info('Inside File: '+FILE_NAME+' Function: '+FUNCTION_NAME,data);

    models.Book.create(data).then((response) => {
        logger.info('Inside File: '+FILE_NAME+' Function: '+FUNCTION_NAME, response);
        res.json(new successHandler(response));
    }).catch((error) => {
        return next(new errors.BadRequestError('Bad Request'));
    })

};

exports.getBooks = function(req, res, next){
    var FUNCTION_NAME = 'getBooks';

    logger.debug('Inside File: '+FILE_NAME+' Function: '+FUNCTION_NAME);

    models.Book.findAll().then((response) => {
        logger.info('Inside File: '+FILE_NAME+' Function: '+FUNCTION_NAME, response);
        res.json(new successHandler(response));
    }).catch((error) => {
        logger.error('Inside File: '+FILE_NAME+' Function: '+FUNCTION_NAME, error);
        return next(new errors.InternalServerError('Some error occurred!!'));
    });

};

exports.deleteBook = function (req, res, next) {

    var FUNCTION_NAME = 'deleteBook';


    logger.debug('Inside File: '+FILE_NAME+' Function: '+FUNCTION_NAME);

    var bookId = req.query.id;


    models.Book.destroy({
        where:{
            id: bookId
        }
    }).then((response) => {
        logger.info('Inside File: '+FILE_NAME+' Function: '+FUNCTION_NAME, response);
        res.json(new successHandler(response));
    }).catch((error) => {
        logger.error('Inside File: '+FILE_NAME+' Function: '+FUNCTION_NAME, error);
        return next(new errors.InternalServerError('Some error occurred!!'));
    });


};

