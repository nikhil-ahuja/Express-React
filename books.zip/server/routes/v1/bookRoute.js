var bodyParser = require('body-parser');
var bookService = require('../../services/bookService');
const router = require('express').Router();
var sessionMiddleware = require('../../middleware/sessionMiddleware');
router.post('/', bodyParser.json(), sessionMiddleware.ensureAuth, bookService.saveBookDetails);

router.get('/', sessionMiddleware.ensureAuth, bookService.getBooks);

router.delete('/',sessionMiddleware.ensureAuth, bookService.deleteBook);

module.exports = router;
