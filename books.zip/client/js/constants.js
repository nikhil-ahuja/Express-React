module.exports = {

    BOOKS: '/books',
    USERS: '/users'

};
